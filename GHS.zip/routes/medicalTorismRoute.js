const express = require('express');
const router = express.Router();
const tourismController = require('../controllers/tourismController');
const pharmacyController = require('../controllers/pharmacyController');
const labController = require('../controllers/labController');
const paymentController = require('../controllers/paymentController');
const upload = require('../middlewares/uploadMiddleware');
const { protect } = require('../middlewares/authMiddleware');

const routeGroup = (prefix, routes) => {
  routes.forEach(([method, path, middlewares, handler]) => {
    router[method](`${prefix}${path}`, ...middlewares, handler);
  });
};

// 📌 Medical Tourism Routes
routeGroup('/tour', [
    ['get', '/packages', [], tourismController.getPackages],
    ['post', '/packages', [protect, upload.single('image')], tourismController.createPackage], // Upload image
    ['put', '/packages/:id', [protect, upload.single('image')], tourismController.updatePackage], // Allow image update
    ['delete', '/packages/:id', [protect], tourismController.deletePackage],
  
    ['post', '/bookings', [protect], tourismController.bookPackage],
    ['put', '/bookings/:id', [protect], tourismController.updateBooking],
    ['delete', '/bookings/:id', [protect], tourismController.cancelBooking],
]);

// 📌 Pharmacy Routes
routeGroup('/pharmacy', [
  ['get', '/medications', [], pharmacyController.getMedications],
  ['post', '/orders', [protect], pharmacyController.placeOrder],
  ['put', '/orders/:id', [protect], pharmacyController.updateOrder],
  ['delete', '/orders/:id', [protect], pharmacyController.cancelOrder],
]);

// 📌 Laboratory Routes
routeGroup('/lab', [
  ['get', '/tests', [], labController.getTests],
  ['post', '/bookings', [protect], labController.bookTest],
  ['put', '/bookings/:id', [protect], labController.updateBooking],
  ['delete', '/bookings/:id', [protect], labController.cancelBooking],
]);

// 📌 Payment Routes (Flutterwave Integration)
routeGroup('/payments', [
  ['post', '/initiate', [protect], paymentController.initiatePayment],
  ['get', '/verify/:reference', [], paymentController.verifyPayment],
]);

module.exports = router;
