const mongoose = require('mongoose');

const LabBookingSchema = new mongoose.Schema({
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    testId: { type: mongoose.Schema.Types.ObjectId, ref: 'LabTest', required: true },
    status: { type: String, enum: ['Pending', 'Completed', 'Canceled'], default: 'Pending' }
}, { timestamps: true });

module.exports = mongoose.model('LabBooking', LabBookingSchema);