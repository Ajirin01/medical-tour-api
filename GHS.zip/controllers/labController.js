const LabTest = require('../models/LabTest');
const LabBooking = require('../models/LabBooking');

exports.getTests = async (req, res) => {
    try {
        const tests = await LabTest.find();
        res.status(200).json(tests);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.bookTest = async (req, res) => {
    try {
        const { patientId, testId } = req.body;
        const newBooking = new LabBooking({ patientId, testId, status: 'Pending' });
        await newBooking.save();
        res.status(201).json({ message: 'Lab test booked', newBooking });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.updateBooking = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedBooking = await LabBooking.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json({ message: 'Booking updated', updatedBooking });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.cancelBooking = async (req, res) => {
    try {
        const { id } = req.params;
        await LabBooking.findByIdAndDelete(id);
        res.status(200).json({ message: 'Booking canceled' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};