const Medication = require('../models/Medication');
const Order = require('../models/Order');

exports.getMedications = async (req, res) => {
    try {
        const medications = await Medication.find();
        res.status(200).json(medications);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.placeOrder = async (req, res) => {
    try {
        const { patientId, medicationId, quantity } = req.body;
        const newOrder = new Order({ patientId, medicationId, quantity, status: 'Pending' });
        await newOrder.save();
        res.status(201).json({ message: 'Order placed', newOrder });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.updateOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedOrder = await Order.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json({ message: 'Order updated', updatedOrder });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

exports.cancelOrder = async (req, res) => {
    try {
        const { id } = req.params;
        await Order.findByIdAndDelete(id);
        res.status(200).json({ message: 'Order canceled' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};